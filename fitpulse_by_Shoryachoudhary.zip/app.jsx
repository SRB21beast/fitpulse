import { Fragment, jsxDEV } from "react/jsx-dev-runtime";
import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
const foods = [
  { name: "Paneer", kind: "vegetarian", calories: 265, protein: 18.3, carbs: 1.2, fiber: 0, sugar: 0.5, fat: 20.8, sat: 13.3, chol: 56, sodium: 22, potassium: 138, calcium: 208, iron: 0.2, vitA: 210, vitC: 0, vitD: 0.4, b12: 0.8 },
  { name: "Dal, cooked", kind: "vegan", calories: 116, protein: 9, carbs: 20.1, fiber: 7.9, sugar: 1.8, fat: 0.4, sat: 0.1, chol: 0, sodium: 2, potassium: 369, calcium: 19, iron: 3.3, vitA: 8, vitC: 1.5, vitD: 0, b12: 0 },
  { name: "Chana, cooked", kind: "vegan", calories: 164, protein: 8.9, carbs: 27.4, fiber: 7.6, sugar: 4.8, fat: 2.6, sat: 0.3, chol: 0, sodium: 7, potassium: 291, calcium: 49, iron: 2.9, vitA: 1, vitC: 1.3, vitD: 0, b12: 0 },
  { name: "Soya chunks, dry", kind: "vegan", calories: 345, protein: 52, carbs: 33, fiber: 13, sugar: 0, fat: 0.5, sat: 0.1, chol: 0, sodium: 15, potassium: 1800, calcium: 350, iron: 20, vitA: 0, vitC: 0, vitD: 0, b12: 0 },
  { name: "Egg, whole", kind: "non-veg", calories: 143, protein: 12.6, carbs: 0.7, fiber: 0, sugar: 0.4, fat: 9.5, sat: 3.1, chol: 372, sodium: 142, potassium: 138, calcium: 56, iron: 1.8, vitA: 160, vitC: 0, vitD: 2, b12: 1.1 },
  { name: "Chicken breast", kind: "non-veg", calories: 165, protein: 31, carbs: 0, fiber: 0, sugar: 0, fat: 3.6, sat: 1, chol: 85, sodium: 74, potassium: 256, calcium: 15, iron: 1, vitA: 21, vitC: 0, vitD: 0.1, b12: 0.3 },
  { name: "Curd, plain", kind: "vegetarian", calories: 61, protein: 3.5, carbs: 4.7, fiber: 0, sugar: 4.7, fat: 3.3, sat: 2.1, chol: 13, sodium: 46, potassium: 155, calcium: 121, iron: 0.1, vitA: 27, vitC: 0, vitD: 0, b12: 0.4 },
  { name: "Tofu, firm", kind: "vegan", calories: 144, protein: 17.3, carbs: 2.8, fiber: 2.3, sugar: 0.6, fat: 8.7, sat: 1.3, chol: 0, sodium: 14, potassium: 237, calcium: 683, iron: 2.7, vitA: 0, vitC: 0.2, vitD: 0, b12: 0 },
  { name: "Almonds", kind: "vegan", calories: 579, protein: 21.2, carbs: 21.6, fiber: 12.5, sugar: 4.4, fat: 49.9, sat: 3.8, chol: 0, sodium: 1, potassium: 733, calcium: 269, iron: 3.7, vitA: 0, vitC: 0, vitD: 0, b12: 0 },
  { name: "Greek yogurt, plain", kind: "vegetarian", calories: 97, protein: 9, carbs: 3.9, fiber: 0, sugar: 3.2, fat: 5, sat: 2.4, chol: 13, sodium: 35, potassium: 141, calcium: 100, iron: 0.1, vitA: 30, vitC: 0, vitD: 0, b12: 0.8 },
  { name: "Oats, dry", kind: "vegan", calories: 389, protein: 16.9, carbs: 66.3, fiber: 10.6, sugar: 0.9, fat: 6.9, sat: 1.2, chol: 0, sodium: 2, potassium: 429, calcium: 54, iron: 4.7, vitA: 0, vitC: 0, vitD: 0, b12: 0 },
  { name: "Peanuts", kind: "vegan", calories: 567, protein: 25.8, carbs: 16.1, fiber: 8.5, sugar: 4.7, fat: 49.2, sat: 6.3, chol: 0, sodium: 18, potassium: 705, calcium: 92, iron: 4.6, vitA: 0, vitC: 0, vitD: 0, b12: 0 }
];
const base = { name: "Alex Morgan", age: 28, gender: "female", height: 168, weight: 64, goal: "maintain", activity: "moderate", unit: "metric", steps: 6842, stepGoal: 1e4, water: 5, waterGoal: 8, active: 34, burned: 438, calorieGoal: 500, calorieTarget: 2050, proteinTarget: 120, carbsTarget: 250, fatTarget: 68, diary: [], workouts: [], weights: [66.2, 65.8, 65.5, 65.1, 64.8, 64.5, 64], theme: "dark" };
function load(email = "local") {
  try {
    return { ...base, ...JSON.parse(localStorage.getItem("fitpulse-data:" + email) || "{}") };
  } catch {
    return base;
  }
}
const names = { dashboard: "Your activity", body: "Body & health", activity: "Steps & activity", nutrition: "Nutrition", progress: "Your progress", profile: "Profile & settings" };
const nav = [["dashboard", "Dashboard", "grid"], ["body", "Body stats", "body"], ["activity", "Activity", "steps"], ["nutrition", "Nutrition", "food"], ["progress", "Progress", "chart"], ["profile", "Profile", "user"]];
const ic = { grid: /* @__PURE__ */ jsxDEV(Fragment, { children: [
  /* @__PURE__ */ jsxDEV("rect", { x: "3", y: "3", width: "7", height: "7", rx: "1.5" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 18
  }),
  /* @__PURE__ */ jsxDEV("rect", { x: "14", y: "3", width: "7", height: "7", rx: "1.5" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 67
  }),
  /* @__PURE__ */ jsxDEV("rect", { x: "3", y: "14", width: "7", height: "7", rx: "1.5" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 117
  }),
  /* @__PURE__ */ jsxDEV("rect", { x: "14", y: "14", width: "7", height: "7", rx: "1.5" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 167
  })
] }, void 0, true, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 16
}), body: /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("path", { d: "M12 3v4m-4 1a4 4 0 1 0 8 0M5 21l2-7 5-2 5 2 2 7" }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 229
}) }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 227
}), steps: /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("path", { d: "M7 4c2 0 3 2 3 4s-1 3-3 3-3-2-3-4 1-3 3-3Zm9 9c2 0 4 2 4 4s-2 4-4 4-4-2-4-4 2-4 4-4Z" }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 300
}) }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 298
}), food: /* @__PURE__ */ jsxDEV(Fragment, { children: [
  /* @__PURE__ */ jsxDEV("path", { d: "M12 7c3-3 7-2 8 1 1 5-2 12-6 12-1 0-1-1-2-1s-2 1-3 1c-4 0-7-7-5-12 1-3 5-4 8-1Z" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 407
  }),
  /* @__PURE__ */ jsxDEV("path", { d: "M12 7c0-3 2-5 5-5" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 498
  })
] }, void 0, true, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 405
}), chart: /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("path", { d: "M3 3v18h18M7 14l4-4 4 3 6-7" }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 539
}) }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 537
}), user: /* @__PURE__ */ jsxDEV(Fragment, { children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "8", r: "4" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 589
  }),
  /* @__PURE__ */ jsxDEV("path", { d: "M5 21c0-4 3-7 7-7s7 3 7 7" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 619
  })
] }, void 0, true, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 587
}), sun: /* @__PURE__ */ jsxDEV(Fragment, { children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "4" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 666
  }),
  /* @__PURE__ */ jsxDEV("path", { d: "M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 697
  })
] }, void 0, true, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 664
}), moon: /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("path", { d: "M21 13A9 9 0 0 1 11 3 9 9 0 1 0 21 13Z" }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 816
}) }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 814
}), flame: /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("path", { d: "M8 14c-1-5 3-7 4-11 3 3 6 6 4 11 2-1 3-3 3-3 2 7-2 11-7 11s-9-4-7-10c1 2 2 3 3 2Z" }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 878
}) }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 876
}), water: /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("path", { d: "M12 22a7 7 0 0 0 7-7c0-4-7-13-7-13S5 11 5 15a7 7 0 0 0 7 7Z" }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 983
}) }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 981
}), bolt: /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("path", { d: "m13 2-3 9h7L9 22l2-9H5l8-11Z" }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 1065
}) }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 1063
}), crown: /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("path", { d: "m2 8 5 4 5-8 5 8 5-4-2 12H4L2 8Z" }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 1117
}) }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 1115
}), target: /* @__PURE__ */ jsxDEV(Fragment, { children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "9" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 1174
  }),
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "5" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 1205
  }),
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "1" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 1236
  })
] }, void 0, true, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 1172
}), check: /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("path", { d: "m5 12 4 4L19 6" }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 1279
}) }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 1277
}), close: /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("path", { d: "m18 6-12 12M6 6l12 12" }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 1317
}) }, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 1315
}), share: /* @__PURE__ */ jsxDEV(Fragment, { children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "18", cy: "5", r: "3" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 1362
  }),
  /* @__PURE__ */ jsxDEV("circle", { cx: "6", cy: "12", r: "3" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 1392
  }),
  /* @__PURE__ */ jsxDEV("circle", { cx: "18", cy: "19", r: "3" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 1422
  }),
  /* @__PURE__ */ jsxDEV("path", { d: "m8.6 10.7 6.8-4.4m-6.8 7 6.8 4.4" }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 1453
  })
] }, void 0, true, {
  fileName: "<stdin>",
  lineNumber: 21,
  columnNumber: 1360
}) };
function I({ n, size = 18 }) {
  return /* @__PURE__ */ jsxDEV("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "round", strokeLinejoin: "round", children: ic[n] || ic.grid }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 22,
    columnNumber: 32
  }, this);
}
const f = (x, d = 0) => Number(x || 0).toLocaleString(void 0, { maximumFractionDigits: d, minimumFractionDigits: d });
function Ring({ value, goal, color, num, unit, exercise, steps }) {
  let rings = [[55, value, goal, "var(--red)"], [43, exercise, 45, "var(--green)"], [31, steps, 1e4, "var(--cyan)"]];
  return /* @__PURE__ */ jsxDEV("div", { className: "ring-wrap", children: [
    /* @__PURE__ */ jsxDEV("svg", { className: "ring-svg", viewBox: "0 0 130 130", children: rings.map(([r, v, g, col], i) => {
      let c = 2 * Math.PI * r;
      return /* @__PURE__ */ jsxDEV(React.Fragment, { children: [
        /* @__PURE__ */ jsxDEV("circle", { className: "ring-track", cx: "65", cy: "65", r, style: { strokeWidth: 7 } }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 24,
          columnNumber: 323
        }, this),
        /* @__PURE__ */ jsxDEV("circle", { className: "ring-progress", cx: "65", cy: "65", r, strokeDasharray: c, strokeDashoffset: c * (1 - Math.min(v / Math.max(g, 1), 1)), style: { stroke: col, strokeWidth: 7 } }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 24,
          columnNumber: 401
        }, this)
      ] }, i, true, {
        fileName: "<stdin>",
        lineNumber: 24,
        columnNumber: 299
      }, this);
    }) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 24,
      columnNumber: 197
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ring-center", children: [
      /* @__PURE__ */ jsxDEV("strong", { children: num }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 24,
        columnNumber: 621
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: unit }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 24,
        columnNumber: 643
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 24,
      columnNumber: 592
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 24,
    columnNumber: 170
  }, this);
}
function CardStat({ title, value, unit, color }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "panel stat-card", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "stat-top", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "tiny-label", children: title }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 25,
        columnNumber: 111
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "stat-symbol", style: { color }, children: /* @__PURE__ */ jsxDEV(I, { n: "bolt", size: 14 }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 25,
        columnNumber: 206
      }, this) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 25,
        columnNumber: 154
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 25,
      columnNumber: 85
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "stat-value", children: [
      value,
      " ",
      /* @__PURE__ */ jsxDEV("span", { className: "stat-unit", children: unit }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 25,
        columnNumber: 278
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 25,
      columnNumber: 242
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 25,
    columnNumber: 52
  }, this);
}
function Chart({ values, second = false }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "chart-area", children: values.map((v, i) => /* @__PURE__ */ jsxDEV("div", { className: "chart-col", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "bar-pair", children: [
      second && /* @__PURE__ */ jsxDEV("i", { className: "bar calories", style: { height: Math.max(8, v * 0.065) + "%" } }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 26,
        columnNumber: 163
      }, this),
      /* @__PURE__ */ jsxDEV("i", { className: "bar steps", style: { height: Math.max(5, v / 100) + "%" } }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 26,
        columnNumber: 235
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 26,
      columnNumber: 128
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "bar-day", children: ["M", "T", "W", "T", "F", "S", "S"][i] }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 26,
      columnNumber: 306
    }, this)
  ] }, i, true, {
    fileName: "<stdin>",
    lineNumber: 26,
    columnNumber: 93
  }, this)) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 26,
    columnNumber: 46
  }, this);
}
function AuthScreen({ onAuth }) {
  const [mode, Mode] = useState("login"), [name, Name] = useState(""), [email, Email] = useState(""), [password, Password] = useState(""), [busy, Busy] = useState(false), [error, Error2] = useState("");
  async function submit(e) {
    e.preventDefault();
    Error2("");
    Busy(true);
    try {
      const endpoint = mode === "signup" ? "/api/account/register" : "/api/account/login", body = { email, password, ...mode === "signup" ? { name } : {} }, r = await fetch(endpoint, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) }), data = await r.json();
      if (!r.ok) throw new Error2(data.error || "Unable to continue.");
      onAuth(data.account);
    } catch (e2) {
      Error2(e2.message || "Unable to reach FitPulse. Try again.");
    } finally {
      Busy(false);
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "auth-shell", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "auth-card panel", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "auth-brand", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "brand-mark", children: /* @__PURE__ */ jsxDEV(I, { n: "bolt" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 827
        }, this) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 798
        }, this),
        "FitPulse"
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 27,
        columnNumber: 770
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "auth-eyebrow", children: "YOUR HEALTH, IN YOUR HANDS" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 27,
        columnNumber: 861
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { children: mode === "signup" ? "Create your account" : "Welcome back" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 27,
        columnNumber: 923
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "auth-copy", children: mode === "signup" ? "Create an account to access your FitPulse dashboard and place a membership order." : "Log in to see your progress and continue to membership checkout." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 27,
        columnNumber: 986
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: submit, className: "auth-form", children: [
        mode === "signup" && /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Full name" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 27,
            columnNumber: 1270
          }, this),
          /* @__PURE__ */ jsxDEV("input", { autoComplete: "name", value: name, onChange: (e) => Name(e.target.value), placeholder: "Your name", required: true, maxLength: "80" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 27,
            columnNumber: 1294
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 1247
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Email address" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 27,
            columnNumber: 1448
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "email", autoComplete: "email", value: email, onChange: (e) => Email(e.target.value), placeholder: "you@example.com", required: true, maxLength: "254" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 27,
            columnNumber: 1476
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 1425
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Password" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 27,
            columnNumber: 1652
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "password", autoComplete: mode === "signup" ? "new-password" : "current-password", value: password, onChange: (e) => Password(e.target.value), placeholder: mode === "signup" ? "At least 8 characters" : "Your password", required: true, minLength: "8", maxLength: "128" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 27,
            columnNumber: 1675
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 1629
        }, this),
        error && /* @__PURE__ */ jsxDEV("div", { className: "auth-error", role: "alert", children: error }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 1943
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn full auth-submit", disabled: busy, children: busy ? "Please wait..." : mode === "signup" ? "Create account" : "Log in" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 1998
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 27,
        columnNumber: 1183
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "auth-switch", children: [
        mode === "signup" ? "Already have an account?" : "New to FitPulse?",
        " ",
        /* @__PURE__ */ jsxDEV("button", { onClick: () => {
          Mode(mode === "signup" ? "login" : "signup");
          Error2("");
        }, children: mode === "signup" ? "Log in" : "Create an account" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 2229
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 27,
        columnNumber: 2136
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "auth-foot", children: [
        /* @__PURE__ */ jsxDEV(I, { n: "check", size: 14 }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 2390
        }, this),
        " Passwords are hashed on the server. Sign in to Websim first so FitPulse can securely bind your account. Email verification and password reset are not configured yet."
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 27,
        columnNumber: 2363
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 27,
      columnNumber: 737
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-aside", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "auth-orbit", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "orbit-ring orbit-red" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 2648
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "orbit-ring orbit-green" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 2688
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "orbit-ring orbit-cyan" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 2730
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "orbit-core", children: /* @__PURE__ */ jsxDEV(I, { n: "bolt", size: 30 }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 2800
        }, this) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 2771
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 27,
        columnNumber: 2620
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "auth-aside-title", children: "Progress that feels like yours." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 27,
        columnNumber: 2836
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "auth-aside-copy", children: "Your activity and nutrition stay on this device; membership orders are tied to your account." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 27,
        columnNumber: 2907
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 27,
      columnNumber: 2592
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 27,
    columnNumber: 709
  }, this);
}
function App() {
  const [d, S] = useState(load()), [authUser, AuthUser] = useState(null), [authLoading, AuthLoading] = useState(true), [orderBusy, OrderBusy] = useState(false), [page, P] = useState("dashboard"), [plan, Plan] = useState(null), [toast, Toast] = useState(""), [period, Period] = useState("week"), [bmiSaved, SetSaved] = useState(false), [query, Q] = useState(""), [results, R] = useState(foods), [chosen, C] = useState(foods[0]), [busy, B] = useState(false), [filter, Filt] = useState("all"), [meal, Meal] = useState("Breakfast"), [qty, Qty] = useState(100), [workType, WT] = useState("Walking"), [workMin, WM] = useState(30), [workCal, WC] = useState(150), [stepDraft, SD] = useState(String(load().steps)), [orderName, ON] = useState(load().name), [motion, Motion] = useState(false);
  useEffect(() => {
    if (authUser) localStorage.setItem("fitpulse-data:" + authUser.email, JSON.stringify(d));
    document.documentElement.dataset.theme = d.theme;
  }, [d, authUser]);
  useEffect(() => {
    let live = true;
    fetch("/api/account/session").then((r) => r.json()).then((b) => {
      if (live && b.account) {
        AuthUser(b.account);
        S(load(b.account.email));
        ON(b.account.name);
      }
    }).catch(() => {
    }).finally(() => {
      if (live) AuthLoading(false);
    });
    return () => {
      live = false;
    };
  }, []);
  useEffect(() => {
    SD(String(d.steps));
  }, [d.steps]);
  useEffect(() => {
    if (toast) {
      let t = setTimeout(() => Toast(""), 2300);
      return () => clearTimeout(t);
    }
  }, [toast]);
  const set = (key, val) => S((x) => ({ ...x, [key]: val })), go = (p) => {
    Plan(null);
    P(p);
  }, today = new Intl.DateTimeFormat("en", { weekday: "long", month: "long", day: "numeric" }).format(/* @__PURE__ */ new Date());
  const dist = d.steps * 75e-5, calStep = Math.round(d.steps * 0.04), cals = d.diary.reduce((a, x) => a + x.calories, 0), prot = d.diary.reduce((a, x) => a + x.protein, 0), carbs = d.diary.reduce((a, x) => a + x.carbs, 0), fat = d.diary.reduce((a, x) => a + x.fat, 0), pct = Math.min(d.steps / d.stepGoal, 1), weekly = [4930, 7120, 6250, 9840, 8310, 5680, d.steps], burn = [312, 467, 402, 621, 535, 391, d.burned];
  const h = Number(d.height) || 168, w = Number(d.weight) || 64, bmi = w / (h / 100) ** 2, category = bmi < 18.5 ? "Underweight" : bmi < 25 ? "Normal" : bmi < 30 ? "Overweight" : "Obese", catColor = bmi < 18.5 ? "var(--cyan)" : bmi < 25 ? "var(--green)" : bmi < 30 ? "#ffc55f" : "var(--red)", bmr = (d.gender === "male" ? 5 : -161) + 10 * w + 6.25 * h - 5 * d.age, factor = { sedentary: 1.2, light: 1.375, moderate: 1.55, active: 1.725, very: 1.9 }[d.activity] || 1.55, need = Math.round(bmr * factor);
  function stepChange(n) {
    set("steps", Math.max(0, Math.round(Number(n) || 0)));
  }
  function search(e) {
    e.preventDefault();
    if (!query.trim()) return;
    B(true);
    fetch("https://world.openfoodfacts.org/cgi/search.pl?search_terms=" + encodeURIComponent(query) + "&search_simple=1&action=process&json=1&page_size=8").then((x) => x.json()).then((b) => {
      let found = (b.products || []).filter((x) => x.product_name && x.nutriments).map((x) => {
        let n = x.nutriments;
        return { name: x.product_name, kind: "food", brand: x.brands || "Open Food Facts", calories: +(n["energy-kcal_100g"] || 0), protein: +(n.proteins_100g || 0), carbs: +(n.carbohydrates_100g || 0), fiber: +(n.fiber_100g || 0), sugar: +(n.sugars_100g || 0), fat: +(n.fat_100g || 0), sat: +(n["saturated-fat_100g"] || 0), chol: +(n.cholesterol_100g || 0), sodium: +(n.sodium_100g || 0) * 1e3, potassium: +(n.potassium_100g || 0) * 1e3, calcium: +(n.calcium_100g || 0) * 1e3, iron: +(n.iron_100g || 0) * 1e3, vitA: +(n["vitamin-a_100g"] || 0), vitC: +(n["vitamin-c_100g"] || 0), vitD: +(n["vitamin-d_100g"] || 0), b12: +(n["vitamin-b12_100g"] || 0) };
      });
      if (found.length) {
        R(found);
        C(found[0]);
      } else {
        let local = foods.filter((x) => x.name.toLowerCase().includes(query.toLowerCase()));
        R(local.length ? local : foods);
        C((local.length ? local : foods)[0]);
        Toast("No online match. Showing common foods.");
      }
    }).catch(() => {
      let local = foods.filter((x) => x.name.toLowerCase().includes(query.toLowerCase()));
      R(local.length ? local : foods);
      C((local.length ? local : foods)[0]);
      Toast("Food database unavailable. Showing built-in foods.");
    }).finally(() => B(false));
  }
  function addFood() {
    if (!chosen) return;
    let m = (Number(qty) || 100) / 100;
    S((x) => ({ ...x, diary: [...x.diary, { id: Date.now(), name: chosen.name, meal, quantity: Number(qty) || 100, calories: Math.round(chosen.calories * m), protein: +(chosen.protein * m).toFixed(1), carbs: +(chosen.carbs * m).toFixed(1), fat: +(chosen.fat * m).toFixed(1) }] }));
    Toast("Added to your food diary");
  }
  function addWorkout() {
    let z = { id: Date.now(), type: workType, duration: +workMin || 0, calories: +workCal || 0 };
    S((x) => ({ ...x, workouts: [z, ...x.workouts], active: x.active + z.duration, burned: x.burned + z.calories }));
    Toast("Workout logged");
  }
  function saveBody() {
    S((x) => ({ ...x, weights: [...x.weights, +x.weight] }));
    SetSaved(true);
    Toast("Body stats saved");
  }
  function theme() {
    set("theme", d.theme === "dark" ? "light" : "dark");
  }
  async function shareProject() {
    try {
      const project = await window.websim.getCurrentProject();
      if (!project?.id) throw new Error("Project link unavailable");
      const url = "https://websim.com/p/" + project.id;
      if (navigator.share) {
        await navigator.share({ title: project.title || "FitPulse", url });
        return;
      }
      await navigator.clipboard.writeText(url);
      Toast("Shareable link copied");
    } catch (e) {
      if (e.name !== "AbortError") Toast(e.message || "Could not share this project");
    }
  }
  async function buy(p) {
    OrderBusy(true);
    try {
      let r = await fetch("/api/orders", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ plan: p.key }) }), b = await r.json();
      if (!r.ok) throw new Error(b.error || "Could not start checkout.");
      Plan({ key: p.key, id: b.order.id, name: b.order.name, price: b.order.amount, createdAt: b.order.createdAt });
      ON(d.name);
      P("profile");
    } catch (e) {
      Toast(e.message);
    } finally {
      OrderBusy(false);
    }
  }
  function confirm() {
    let total = plan.price, msg = ["Thank you for your FitPulse order!", "", "Membership: " + plan.name, "Quantity: 1", "Total: Rs " + f(total, 2), orderName.trim() ? "Name: " + orderName.trim() : "", "Date: " + (/* @__PURE__ */ new Date()).toLocaleString(), "", "Order reference: " + plan.id, "I have completed the UPI payment."].filter(Boolean).join(String.fromCharCode(10));
    window.open("https://wa.me/917303232301?text=" + encodeURIComponent(msg), "_blank", "noopener,noreferrer");
    S((x) => ({ ...x, name: orderName.trim() || x.name, pendingMembership: plan.name }));
    Plan(null);
    Toast("WhatsApp opened. Membership activation is pending payment confirmation.");
  }
  function sensor() {
    if (!("DeviceMotionEvent" in window)) {
      Toast("Motion sensor is not supported on this device");
      return;
    }
    let on = () => {
      Motion(true);
      let last = 0;
      let fn = (e) => {
        let a = e.accelerationIncludingGravity;
        if (!a) return;
        let m = Math.hypot(a.x || 0, a.y || 0, a.z || 0);
        if (Math.abs(m - 9.8) > 2.5 && Date.now() - last > 550) {
          last = Date.now();
          S((x) => ({ ...x, steps: x.steps + 1 }));
        }
      };
      window.addEventListener("devicemotion", fn);
      setTimeout(() => {
        window.removeEventListener("devicemotion", fn);
        Motion(false);
      }, 6e4);
    };
    if (typeof DeviceMotionEvent.requestPermission === "function") DeviceMotionEvent.requestPermission().then((x) => x === "granted" ? on() : Toast("Motion permission was not granted")).catch(() => Toast("Could not access motion sensor"));
    else on();
  }
  const navBtn = (x, mob = false) => /* @__PURE__ */ jsxDEV("button", { className: "nav-item " + (page === x[0] ? "active" : ""), onClick: () => go(x[0]), children: [
    /* @__PURE__ */ jsxDEV("span", { className: "nav-icon", children: /* @__PURE__ */ jsxDEV(I, { n: x[2] }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 43,
      columnNumber: 148
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 43,
      columnNumber: 121
    }, this),
    /* @__PURE__ */ jsxDEV("span", { children: x[1] }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 43,
      columnNumber: 168
    }, this)
  ] }, x[0], true, {
    fileName: "<stdin>",
    lineNumber: 43,
    columnNumber: 29
  }, this);
  const side = /* @__PURE__ */ jsxDEV("aside", { className: "sidebar", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "brand", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "brand-mark", children: /* @__PURE__ */ jsxDEV(I, { n: "bolt" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 44,
        columnNumber: 91
      }, this) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 44,
        columnNumber: 62
      }, this),
      "FitPulse"
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 44,
      columnNumber: 39
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "side-label", children: "Workspace" }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 44,
      columnNumber: 125
    }, this),
    /* @__PURE__ */ jsxDEV("nav", { className: "nav-list", children: nav.map((x) => navBtn(x)) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 44,
      columnNumber: 168
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "side-bottom", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "membership-mini", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "mini-title", children: "Make every day count" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 44,
          columnNumber: 285
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mini-copy", children: "Unlock deeper insights with FitPulse Plus." }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 44,
          columnNumber: 335
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn small", onClick: () => go("profile"), children: "Explore membership" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 44,
          columnNumber: 406
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 44,
        columnNumber: 252
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "nav-item", onClick: theme, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "nav-icon", children: /* @__PURE__ */ jsxDEV(I, { n: d.theme === "dark" ? "sun" : "moon" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 44,
          columnNumber: 569
        }, this) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 44,
          columnNumber: 542
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "Switch theme" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 44,
          columnNumber: 614
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 44,
        columnNumber: 497
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 44,
      columnNumber: 223
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 44,
    columnNumber: 12
  }, this);
  function dashboard() {
    return /* @__PURE__ */ jsxDEV("div", { className: "page", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "dashboard-grid", children: [
        /* @__PURE__ */ jsxDEV("section", { className: "panel hero-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "hero-top", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "eyebrow", children: "Your daily activity" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 151
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "hero-title", children: [
                "A little better, ",
                /* @__PURE__ */ jsxDEV("span", { children: "every day." }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 45,
                  columnNumber: 246
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 201
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 146
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "goal-chip", children: [
              Math.round(pct * 100),
              "% of step goal"
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 281
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 120
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rings-row", children: [
            /* @__PURE__ */ jsxDEV(Ring, { value: d.burned, goal: d.calorieGoal, color: "var(--red)", num: f(d.burned), unit: "KCAL", exercise: d.active, steps: d.steps }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 382
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "ring-legend", children: [["Move", f(d.burned), "of " + d.calorieGoal + " kcal", "var(--red)"], ["Exercise", f(d.active), "of 45 min", "var(--green)"], ["Steps", f(d.steps), "of " + f(d.stepGoal), "var(--cyan)"]].map((a) => /* @__PURE__ */ jsxDEV("div", { className: "ring-legend-row", children: [
              /* @__PURE__ */ jsxDEV("i", { className: "ring-dot", style: { background: a[3] } }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 764
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "ring-legend-copy", children: [
                /* @__PURE__ */ jsxDEV("strong", { children: a[0] }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 45,
                  columnNumber: 849
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: a[2] }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 45,
                  columnNumber: 872
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 815
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "ring-legend-value", children: a[1] }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 897
              }, this)
            ] }, a[0], true, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 720
            }, this)) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 512
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 355
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 45,
          columnNumber: 83
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "panel streak-card", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "streak-top", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "eyebrow", children: "Your streak" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 45,
                  columnNumber: 1051
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "streak-number", children: [
                  Math.max(4, Math.floor(d.steps / 2e3)),
                  /* @__PURE__ */ jsxDEV("small", { children: " days" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 45,
                    columnNumber: 1162
                  }, this)
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 45,
                  columnNumber: 1093
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 1046
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--green)" }, children: /* @__PURE__ */ jsxDEV(I, { n: "flame", size: 27 }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 1231
              }, this) }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 1194
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 1018
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "muted", style: { fontSize: 11, marginTop: 7 }, children: "You're building a rhythm. Keep it going." }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 1268
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 1013
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "streak-days", children: ["M", "T", "W", "T", "F", "S", "S"].map((x, i) => /* @__PURE__ */ jsxDEV("div", { className: "streak-day " + (i < 5 ? "done" : ""), children: [
            /* @__PURE__ */ jsxDEV("i", { children: i < 5 ? /* @__PURE__ */ jsxDEV(I, { n: "check", size: 12 }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 1511
            }, this) : x }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 1503
            }, this),
            x
          ] }, i, true, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 1448
          }, this)) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 1377
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 45,
          columnNumber: 974
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 45,
        columnNumber: 51
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "stats-grid", children: [["Steps", f(d.steps), "steps", "var(--green)"], ["Distance", dist.toFixed(2), "km", "var(--cyan)"], ["Calories burned", f(d.burned + calStep), "kcal", "var(--red)"], ["Active minutes", f(d.active), "min", "var(--purple)"], ["Water intake", d.water + "/" + d.waterGoal, "glasses", "var(--cyan)"], ["Calories eaten", f(cals), "kcal", "var(--red)"], ["Protein eaten", f(prot, 1), "g", "var(--green)"]].map((x) => /* @__PURE__ */ jsxDEV(CardStat, { title: x[0], value: x[1], unit: x[2], color: x[3] }, x[0], false, {
        fileName: "<stdin>",
        lineNumber: 45,
        columnNumber: 1977
      }, this)) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 45,
        columnNumber: 1575
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "lower-grid", children: [
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad chart-panel", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "This week" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 2168
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Your movement at a glance" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 2214
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 2163
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "chart-legend", children: [
              /* @__PURE__ */ jsxDEV("span", { children: [
                /* @__PURE__ */ jsxDEV("i", {}, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 45,
                  columnNumber: 2312
                }, this),
                "Steps"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 2306
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                /* @__PURE__ */ jsxDEV("i", { className: "second" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 45,
                  columnNumber: 2334
                }, this),
                "Calories"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 2328
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 2276
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 2135
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "chart-area", children: weekly.map((v, i) => /* @__PURE__ */ jsxDEV("div", { className: "chart-col", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bar-pair", children: [
              /* @__PURE__ */ jsxDEV("i", { className: "bar calories", style: { height: burn[i] / 7 + "%" } }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 2492
              }, this),
              /* @__PURE__ */ jsxDEV("i", { className: "bar steps", style: { height: v / 80 + "%" } }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 2552
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 2466
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "bar-day", children: ["M", "T", "W", "T", "F", "S", "S"][i] }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 2610
            }, this)
          ] }, i, true, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 2431
          }, this)) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 2384
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 45,
          columnNumber: 2086
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Daily goals" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 2771
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Small wins add up" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 2819
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 2766
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "stat-symbol", children: /* @__PURE__ */ jsxDEV(I, { n: "target" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 2903
            }, this) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 2873
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 2738
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "goal-progress", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "goal-foot", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Step goal" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 2989
              }, this),
              /* @__PURE__ */ jsxDEV("strong", { children: [
                f(d.steps),
                " / ",
                f(d.stepGoal)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 3011
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 2962
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "progress-track", children: /* @__PURE__ */ jsxDEV("div", { className: "progress-fill", style: { width: Math.min(100, pct * 100) + "%" } }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 3096
            }, this) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 3064
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "goal-foot muted", children: [
              /* @__PURE__ */ jsxDEV("span", { children: pct >= 1 ? "Goal reached. Nice work!" : f(d.stepGoal - d.steps) + " steps to go" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 3209
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                Math.round(pct * 100),
                "%"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 3294
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 3176
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 2931
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "water-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "water-glass", children: /* @__PURE__ */ jsxDEV(I, { n: "water" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 3397
            }, this) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 3368
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "water-copy", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "water-count", children: [
                d.water,
                " ",
                /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 500, fontSize: 11 }, children: [
                  "of ",
                  d.waterGoal,
                  " glasses"
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 45,
                  columnNumber: 3484
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 3445
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "water-target", children: "Hydration goal" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 3564
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 3417
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "water-controls", children: [
              /* @__PURE__ */ jsxDEV("button", { className: "mini-btn", onClick: () => set("water", Math.max(0, d.water - 1)), children: "-" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 3652
              }, this),
              /* @__PURE__ */ jsxDEV("button", { className: "mini-btn", onClick: () => set("water", Math.min(d.waterGoal, d.water + 1)), children: "+" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 45,
                columnNumber: 3740
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 3620
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 3341
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 45,
          columnNumber: 2701
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 45,
        columnNumber: 2058
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "panel membership-banner", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "banner-content", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "banner-icon", children: /* @__PURE__ */ jsxDEV(I, { n: "crown" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 3973
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 3943
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "banner-title", children: "A little more insight. A lot more you." }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 3999
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "banner-sub", children: "Explore FitPulse membership and find your next level." }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 45,
              columnNumber: 4073
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 45,
            columnNumber: 3994
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 45,
          columnNumber: 3911
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn small", onClick: () => go("profile"), children: "Explore plans" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 45,
          columnNumber: 4172
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 45,
        columnNumber: 3866
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 45,
      columnNumber: 29
    }, this);
  }
  function weightChart() {
    let v = d.weights.slice(-8);
    if (v.length < 2) return /* @__PURE__ */ jsxDEV("div", { className: "empty-state", children: "Save your stats to start your weight history." }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 46,
      columnNumber: 71
    }, this);
    let min = Math.min(...v) - 0.8, max = Math.max(...v) + 0.8, pts = v.map((n, i) => i / (v.length - 1) * 100 + "," + (90 - (n - min) / (max - min) * 70)).join(" ");
    return /* @__PURE__ */ jsxDEV("div", { style: { marginTop: 10 }, children: [
      /* @__PURE__ */ jsxDEV("svg", { className: "history-visual", viewBox: "0 0 100 100", preserveAspectRatio: "none", children: [
        /* @__PURE__ */ jsxDEV("polyline", { points: pts }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 46,
          columnNumber: 395
        }, this),
        v.map((n, i) => /* @__PURE__ */ jsxDEV("circle", { cx: i / (v.length - 1) * 100, cy: 90 - (n - min) / (max - min) * 70, r: "1.6" }, i, false, {
          fileName: "<stdin>",
          lineNumber: 46,
          columnNumber: 433
        }, this))
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 46,
        columnNumber: 314
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "goal-foot muted", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Oldest" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 46,
          columnNumber: 552
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "Today" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 46,
          columnNumber: 571
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 46,
        columnNumber: 519
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 46,
      columnNumber: 286
    }, this);
  }
  function bodyPage() {
    let imperial = d.unit === "imperial";
    return /* @__PURE__ */ jsxDEV("div", { className: "page", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "page-intro", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Know your baseline." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 116
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Simple numbers, useful context. This is your starting point." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 144
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 47,
          columnNumber: 111
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "segmented", children: [
          /* @__PURE__ */ jsxDEV("button", { className: !imperial ? "active" : "", onClick: () => set("unit", "metric"), children: "Metric" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 244
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: imperial ? "active" : "", onClick: () => set("unit", "imperial"), children: "Imperial" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 336
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 47,
          columnNumber: 217
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 47,
        columnNumber: 83
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "two-col", children: [
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Your measurements" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 538
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Used to estimate your health metrics" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 592
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 533
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "status-pill", children: "ESTIMATE" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 665
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 505
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-grid", style: { marginTop: 18 }, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
              /* @__PURE__ */ jsxDEV("label", { children: [
                "Height (",
                imperial ? "in" : "cm",
                ")"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 789
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "number", value: imperial ? (h / 2.54).toFixed(1) : d.height, onChange: (e) => set("height", imperial ? +e.target.value * 2.54 : +e.target.value) }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 833
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 766
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
              /* @__PURE__ */ jsxDEV("label", { children: [
                "Weight (",
                imperial ? "lb" : "kg",
                ")"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 1004
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "number", value: imperial ? (w * 2.20462).toFixed(1) : d.weight, onChange: (e) => set("weight", imperial ? +e.target.value / 2.20462 : +e.target.value) }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 1048
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 981
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Age" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 1225
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "number", value: d.age, onChange: (e) => set("age", +e.target.value) }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 1243
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 1202
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Gender" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 1349
              }, this),
              /* @__PURE__ */ jsxDEV("select", { value: d.gender, onChange: (e) => set("gender", e.target.value), children: [
                /* @__PURE__ */ jsxDEV("option", { value: "female", children: "Female" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 47,
                  columnNumber: 1438
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "male", children: "Male" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 47,
                  columnNumber: 1476
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 1370
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 1326
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "field span-2", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Activity level" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 1555
              }, this),
              /* @__PURE__ */ jsxDEV("select", { value: d.activity, onChange: (e) => set("activity", e.target.value), children: [
                /* @__PURE__ */ jsxDEV("option", { value: "sedentary", children: "Mostly sitting" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 47,
                  columnNumber: 1656
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "light", children: "Lightly active (1-3 days/week)" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 47,
                  columnNumber: 1705
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "moderate", children: "Moderately active (3-5 days/week)" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 47,
                  columnNumber: 1766
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "active", children: "Very active (6-7 days/week)" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 47,
                  columnNumber: 1833
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "very", children: "Extra active / physical job" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 47,
                  columnNumber: 1892
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 1584
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 1525
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 716
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "metric-result", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bmi-number", children: bmi.toFixed(1) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 2001
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bmi-category", style: { color: catColor }, children: category }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 2056
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "muted", style: { fontSize: 10, marginTop: 4 }, children: "Your estimated BMI" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 2127
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 2051
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 1970
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bmi-scale", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bmi-spectrum", children: /* @__PURE__ */ jsxDEV("i", { className: "bmi-pointer", style: { left: Math.max(2, Math.min(98, (bmi - 14) / 26 * 100)) + "%" } }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 2277
            }, this) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 2247
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bmi-labels", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Underweight" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 2399
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Normal" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 2423
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Overweight" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 2442
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Obese" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 2465
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 2371
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 2220
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn", style: { marginTop: 20 }, onClick: saveBody, children: [
            /* @__PURE__ */ jsxDEV(I, { n: "check", size: 15 }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 2561
            }, this),
            " Save today's stats"
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 2495
          }, this),
          bmiSaved && /* @__PURE__ */ jsxDEV("span", { className: "status-pill", style: { marginLeft: 9 }, children: "SAVED" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 2624
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 47,
          columnNumber: 468
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Your daily targets" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 2737
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Personalized estimates from your profile" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 2792
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { marginTop: 16 }, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "result-metric", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Basal metabolic rate" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 2922
              }, this),
              /* @__PURE__ */ jsxDEV("strong", { children: [
                f(bmr),
                " kcal"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 2955
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 2891
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "result-metric", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Daily energy needs" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 3022
              }, this),
              /* @__PURE__ */ jsxDEV("strong", { children: [
                f(need),
                " kcal"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 3053
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 2991
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "result-metric", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Weight goal" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 3121
              }, this),
              /* @__PURE__ */ jsxDEV("strong", { style: { textTransform: "capitalize" }, children: d.goal }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 3145
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 3090
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 2863
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "macro-targets", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "macro-target", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: [
                Math.round(need * 0.25 / 4),
                "g"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 3280
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Protein" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 3322
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 3250
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "macro-target", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: [
                Math.round(need * 0.5 / 4),
                "g"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 3378
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Carbs" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 3419
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 3348
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "macro-target", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: [
                Math.round(need * 0.25 / 9),
                "g"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 3473
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Fat" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 47,
                columnNumber: 3515
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 47,
              columnNumber: 3443
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 3219
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn secondary full", style: { marginTop: 16 }, onClick: () => {
            S((x) => ({ ...x, calorieTarget: need, proteinTarget: Math.round(need * 0.25 / 4), carbsTarget: Math.round(need * 0.5 / 4), fatTarget: Math.round(need * 0.25 / 9) }));
            Toast("Daily targets updated");
          }, children: "Use these as my daily targets" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 3543
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "settings-note", children: "BMI and calorie estimates are for general guidance only, not a medical diagnosis." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 47,
            columnNumber: 3828
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 47,
          columnNumber: 2700
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 47,
        columnNumber: 443
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", style: { marginTop: 18 }, children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Weight history" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 47,
          columnNumber: 4018
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "A steady trend matters more than a single day" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 47,
          columnNumber: 4069
        }, this),
        weightChart()
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 47,
        columnNumber: 3958
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 47,
      columnNumber: 61
    }, this);
  }
  function activityPage() {
    let vals = period === "week" ? weekly : [4310, 6720, 5910, 8460, 7230, 5120, 9170, 8030, 6880, 10200, 7650, 5500, 0, 0];
    return /* @__PURE__ */ jsxDEV("div", { className: "page", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "page-intro", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Keep your momentum." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 186
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            "Every step counts. Today, you are at ",
            f(d.steps),
            " steps."
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 214
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 48,
          columnNumber: 181
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "status-pill", children: today.toUpperCase() }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 48,
          columnNumber: 283
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 48,
        columnNumber: 153
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "panel step-hero", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "step-circle", children: [
          /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 130 130", children: [
            /* @__PURE__ */ jsxDEV("circle", { className: "track", cx: "65", cy: "65", r: "54" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 440
            }, this),
            /* @__PURE__ */ jsxDEV("circle", { className: "progress", cx: "65", cy: "65", r: "54", strokeDasharray: "339.3", strokeDashoffset: 339.3 * (1 - pct) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 490
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 413
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "center", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: [
              Math.round(pct * 100),
              "%"
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 630
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "OF YOUR GOAL" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 669
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 606
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 48,
          columnNumber: 384
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "step-copy", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "tiny-label", children: "Today's steps" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 733
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "number", children: f(d.steps) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 780
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            f(Math.max(0, d.stepGoal - d.steps)),
            " steps left \xB7 ",
            dist.toFixed(1),
            " km so far"
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 822
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "step-controls", children: [
            /* @__PURE__ */ jsxDEV("button", { className: "mini-btn", onClick: () => stepChange(d.steps - 100), children: "-" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 936
            }, this),
            /* @__PURE__ */ jsxDEV("input", { className: "inline-input", value: stepDraft, onChange: (e) => SD(e.target.value), onBlur: () => stepChange(stepDraft), onKeyDown: (e) => e.key === "Enter" && stepChange(stepDraft) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 1013
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "mini-btn", onClick: () => stepChange(d.steps + 100), children: "+" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 1186
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "btn small", onClick: sensor, disabled: motion, children: motion ? "Sensor on" : "Use motion sensor" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 1263
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 905
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 48,
          columnNumber: 706
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 48,
        columnNumber: 347
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "two-col", style: { marginTop: 16 }, children: [
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Daily step goal" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 1517
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Make it your own" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 1569
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 1512
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "stat-symbol", children: /* @__PURE__ */ jsxDEV(I, { n: "target" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 1652
            }, this) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 1622
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 1484
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "field", style: { marginTop: 17 }, children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Steps per day" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 1726
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", step: "500", value: d.stepGoal, onChange: (e) => set("stepGoal", +e.target.value) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 1754
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 1680
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "quick-add", children: [
            /* @__PURE__ */ jsxDEV("button", { className: "btn secondary small", onClick: () => stepChange(d.steps + 500), children: "+500 steps" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 1885
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "btn secondary small", onClick: () => stepChange(d.steps + 1e3), children: "+1,000 steps" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 1982
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "btn secondary small", onClick: () => stepChange(d.stepGoal), children: "Reach goal" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 2082
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 1858
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "result-metric", style: { marginTop: 17 }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Distance walked" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 2238
            }, this),
            /* @__PURE__ */ jsxDEV("strong", { children: [
              dist.toFixed(2),
              " km"
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 2266
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 2184
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "result-metric", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Estimated calories" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 2340
            }, this),
            /* @__PURE__ */ jsxDEV("strong", { children: [
              f(calStep),
              " kcal"
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 2371
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 2309
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 48,
          columnNumber: 1447
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Log a workout" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 2458
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Add movement beyond your steps" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 2508
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-grid", style: { marginTop: 16 }, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Workout" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 2642
              }, this),
              /* @__PURE__ */ jsxDEV("select", { value: workType, onChange: (e) => WT(e.target.value), children: ["Walking", "Running", "Cycling", "Gym", "Yoga"].map((x) => /* @__PURE__ */ jsxDEV("option", { children: x }, x, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 2775
              }, this)) }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 2664
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 2619
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Duration (min)" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 2843
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "number", value: workMin, onChange: (e) => WM(e.target.value) }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 2872
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 2820
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Calories burned" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 2972
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "number", value: workCal, onChange: (e) => WC(e.target.value) }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 3002
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 2949
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "field", style: { display: "flex", alignItems: "end" }, children: /* @__PURE__ */ jsxDEV("button", { className: "btn full", onClick: addWorkout, children: "Log workout" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 3144
            }, this) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 3079
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 2569
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 48,
          columnNumber: 2421
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 48,
        columnNumber: 1399
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "two-col", style: { marginTop: 16 }, children: [
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: period === "week" ? "This week" : "This month" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 3360
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Daily steps" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 3439
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 3355
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "segmented", children: [
              /* @__PURE__ */ jsxDEV("button", { className: period === "week" ? "active" : "", onClick: () => Period("week"), children: "Week" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 3514
              }, this),
              /* @__PURE__ */ jsxDEV("button", { className: period === "month" ? "active" : "", onClick: () => Period("month"), children: "Month" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 3604
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 3487
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 3327
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "trend-chart", style: { height: 180 }, children: vals.map((v, i) => /* @__PURE__ */ jsxDEV("div", { className: "trend-bar-col", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "trend-bar", style: { height: Math.max(4, v / 110) + "%" } }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 3815
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: period === "week" ? ["M", "T", "W", "T", "F", "S", "S"][i] : i % 3 === 0 ? i + 1 : "" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 3882
            }, this)
          ] }, i, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 3776
          }, this)) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 3709
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 48,
          columnNumber: 3290
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Recent workouts" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 4054
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Your movement, logged" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 4106
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 4049
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "status-pill", children: [
              d.workouts.length,
              " TOTAL"
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 4164
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 4021
          }, this),
          d.workouts.length ? /* @__PURE__ */ jsxDEV("div", { className: "workout-list", children: d.workouts.slice(0, 5).map((x) => /* @__PURE__ */ jsxDEV("div", { className: "workout-item", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "workout-icon", children: /* @__PURE__ */ jsxDEV(I, { n: "bolt" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 4383
            }, this) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 4352
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "workout-copy", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: x.type }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 4433
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                x.duration,
                " min \xB7 Today"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 48,
                columnNumber: 4458
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 4403
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "workout-kcal", children: [
              x.calories,
              " kcal"
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 48,
              columnNumber: 4501
            }, this)
          ] }, x.id, true, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 4311
          }, this)) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 4251
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "empty-state", children: "Your logged workouts will show up here." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 4571
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 48,
          columnNumber: 3984
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 48,
        columnNumber: 3242
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 48,
      columnNumber: 131
    }, this);
  }
  function nutritionPage() {
    let high = foods.filter((x) => x.kind === "vegetarian" || x.kind === "vegan" || x.kind === "non-veg").filter((x) => filter === "all" || x.kind === filter).sort((a, b) => b.protein - a.protein), mTotal = prot * 4 + carbs * 4 + fat * 9, p = mTotal ? prot * 4 / mTotal * 100 : 0, c = mTotal ? p + carbs * 4 / mTotal * 100 : 0;
    let rows = [["Protein", chosen.protein, "g"], ["Carbohydrates", chosen.carbs, "g"], ["Fiber", chosen.fiber, "g"], ["Sugar", chosen.sugar, "g"], ["Total fat", chosen.fat, "g"], ["Saturated fat", chosen.sat, "g"], ["Cholesterol", chosen.chol, "mg"], ["Sodium", chosen.sodium, "mg"], ["Potassium", chosen.potassium, "mg"], ["Calcium", chosen.calcium, "mg"], ["Iron", chosen.iron, "mg"], ["Vitamin A", chosen.vitA, "\xB5g"], ["Vitamin C", chosen.vitC, "mg"], ["Vitamin D", chosen.vitD, "\xB5g"], ["Vitamin B12", chosen.b12, "\xB5g"]];
    return /* @__PURE__ */ jsxDEV("div", { className: "page", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "page-intro", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Eat well, feel good." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 815
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Look up a food or add something you ate today." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 844
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 49,
          columnNumber: 810
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "status-pill", children: "OPEN FOOD FACTS" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 49,
          columnNumber: 903
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 49,
        columnNumber: 782
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "food-layout", children: [
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Food explorer" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 1060
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Search products or browse common foods" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 1110
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 1055
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 1027
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "search-row", style: { marginTop: 15 }, onSubmit: search, children: [
            /* @__PURE__ */ jsxDEV("input", { className: "search-input", placeholder: "Try oats, yogurt, lentils...", value: query, onChange: (e) => Q(e.target.value) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 1261
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "btn small", disabled: busy, children: busy ? "Searching" : "Search" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 1383
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 1191
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "food-results", children: results.filter((x) => filter === "all" || x.kind === filter || x.kind === "food").map((x, i) => /* @__PURE__ */ jsxDEV("button", { className: "food-result " + (chosen.name === x.name ? "selected" : ""), onClick: () => C(x), children: [
            /* @__PURE__ */ jsxDEV("span", { className: "food-thumb", children: x.name[0].toUpperCase() }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 1688
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "food-result-copy", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: x.name }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 1784
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: x.brand || "Per 100 g" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 1809
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 1749
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "food-cal", children: [
              f(x.calories),
              " kcal"
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 1851
            }, this)
          ] }, x.name + i, true, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 1582
          }, this)) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 1472
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 49,
          columnNumber: 990
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "food-detail-title", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { children: chosen.name }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 2009
              }, this),
              /* @__PURE__ */ jsxDEV("p", { children: [
                "Nutrition per 100 g \xB7 ",
                chosen.brand || "Typical values"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 2031
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 2004
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "food-detail-cal", children: [
              f(chosen.calories),
              /* @__PURE__ */ jsxDEV("span", { children: " kcal" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 2151
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 2098
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 1969
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "nutrition-grid", children: rows.map((x) => /* @__PURE__ */ jsxDEV("div", { className: "nutrition-item", children: [
            /* @__PURE__ */ jsxDEV("span", { children: x[0] }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 2269
            }, this),
            /* @__PURE__ */ jsxDEV("strong", { children: [
              f(x[1], 1),
              " ",
              x[2]
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 2288
            }, this)
          ] }, x[0], true, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 2226
          }, this)) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 2181
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "food-add-row", children: [
            /* @__PURE__ */ jsxDEV("select", { value: meal, onChange: (e) => Meal(e.target.value), children: [
              /* @__PURE__ */ jsxDEV("option", { children: "Breakfast" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 2423
              }, this),
              /* @__PURE__ */ jsxDEV("option", { children: "Lunch" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 2449
              }, this),
              /* @__PURE__ */ jsxDEV("option", { children: "Dinner" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 2471
              }, this),
              /* @__PURE__ */ jsxDEV("option", { children: "Snacks" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 2494
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 2367
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", value: qty, onChange: (e) => Qty(e.target.value), "aria-label": "Quantity in grams" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 2526
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "status-pill", style: { display: "grid", placeItems: "center" }, children: "GRAMS" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 2625
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "btn small", onClick: addFood, children: "Add meal" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 2712
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 2337
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 49,
          columnNumber: 1932
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 49,
        columnNumber: 961
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", style: { marginTop: 16 }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "High protein foods" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 2892
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Ranked by protein per 100 g" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 2947
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 2887
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "segmented", children: [["all", "All"], ["vegetarian", "Veg"], ["vegan", "Vegan"], ["non-veg", "Non-veg"]].map((x) => /* @__PURE__ */ jsxDEV("button", { className: filter === x[0] ? "active" : "", onClick: () => Filt(x[0]), children: x[1] }, x[0], false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 3123
          }, this)) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 3011
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 49,
          columnNumber: 2859
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "protein-grid", children: high.slice(0, 8).map((x) => /* @__PURE__ */ jsxDEV("div", { className: "protein-card", onClick: () => {
          C(x);
          window.scrollTo({ top: 0, behavior: "smooth" });
        }, children: [
          /* @__PURE__ */ jsxDEV("strong", { children: x.name }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 3395
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: x.kind === "non-veg" ? "Non-veg" : x.kind === "vegan" ? "Vegan" : "Vegetarian" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 3420
          }, this),
          /* @__PURE__ */ jsxDEV("b", { children: [
            x.protein,
            "g ",
            /* @__PURE__ */ jsxDEV("small", { children: "protein" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 3517
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 3501
          }, this)
        ] }, x.name, true, {
          fileName: "<stdin>",
          lineNumber: 49,
          columnNumber: 3288
        }, this)) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 49,
          columnNumber: 3234
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 49,
        columnNumber: 2799
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "two-col", style: { marginTop: 16 }, children: [
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Today's food diary" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 3685
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Meals add up to your daily targets" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 3740
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 3680
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "status-pill", children: [
              d.diary.length,
              " ITEMS"
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 3811
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 3652
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(92px,1fr))", gap: 8, marginTop: 14 }, children: [["Calories", f(cals), "of " + d.calorieTarget + " kcal", cals / d.calorieTarget], ["Protein", f(prot, 1) + "g", "of " + d.proteinTarget + "g", prot / d.proteinTarget], ["Carbs", f(carbs, 1) + "g", "of " + d.carbsTarget + "g", carbs / d.carbsTarget], ["Fat", f(fat, 1) + "g", "of " + d.fatTarget + "g", fat / d.fatTarget]].map((x) => /* @__PURE__ */ jsxDEV("div", { className: "macro-target", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: x[1] }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 4305
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: x[2] }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 4328
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "progress-track", children: /* @__PURE__ */ jsxDEV("div", { className: "progress-fill", style: { width: Math.min(100, x[3] * 100) + "%" } }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 4379
            }, this) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 4347
            }, this)
          ] }, x[0], true, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 4264
          }, this)) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 3876
          }, this),
          d.diary.length ? /* @__PURE__ */ jsxDEV("div", { className: "diary-list", children: d.diary.map((x) => /* @__PURE__ */ jsxDEV("div", { className: "diary-item", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "diary-copy", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: x.name }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 4601
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                x.meal,
                " \xB7 ",
                x.quantity,
                " g \xB7 ",
                x.protein,
                "g protein"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 4626
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 4573
            }, this),
            /* @__PURE__ */ jsxDEV("b", { children: [
              x.calories,
              " kcal"
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 4693
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "remove-btn", onClick: () => S((v) => ({ ...v, diary: v.diary.filter((y) => y.id !== x.id) })), children: /* @__PURE__ */ jsxDEV(I, { n: "close", size: 14 }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 4814
            }, this) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 4717
            }, this)
          ] }, x.id, true, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 4534
          }, this)) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 4490
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "empty-state", children: "Add your first meal to start your diary." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 4862
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 49,
          columnNumber: 3615
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Macro balance" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 4985
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Where your calories come from today" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 5035
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "macro-breakdown", style: { marginTop: 19 }, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "macro-donut", style: { "--p": p + "%", "--c": c + "%" }, children: /* @__PURE__ */ jsxDEV("div", { className: "donut-center", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: f(cals) }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 5250
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "CALORIES" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 5276
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 5220
            }, this) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 5157
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "macro-key", children: [["Protein", prot, "var(--green)"], ["Carbs", carbs, "var(--cyan)"], ["Fat", fat, "var(--red)"]].map((x) => /* @__PURE__ */ jsxDEV("div", { className: "macro-key-row", children: [
              /* @__PURE__ */ jsxDEV("i", { style: { background: x[2] } }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 5475
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: x[0] }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 5505
              }, this),
              /* @__PURE__ */ jsxDEV("strong", { children: [
                f(x[1], 1),
                "g"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 49,
                columnNumber: 5524
              }, this)
            ] }, x[0], true, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 5433
            }, this)) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 49,
              columnNumber: 5309
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 5101
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 49,
          columnNumber: 4948
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 49,
        columnNumber: 3567
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 49,
      columnNumber: 760
    }, this);
  }
  function progressPage() {
    let trendSteps = period === "week" ? weekly : [7310, 6840, 8290, 7650, 9120, 6740, 8010, 7280, 9340, 8560, 6970, 8820, 7610, 8430], trendBurn = period === "week" ? burn : [410, 388, 492, 433, 546, 392, 481, 420, 562, 518, 405, 530, 442, 497], badges = [["\u2726", "First steps", "Logged a day", d.steps > 0], ["\u25C6", "Goal getter", "Hit your step goal", d.steps >= d.stepGoal], ["\u2301", "In the groove", "Logged a workout", d.workouts.length > 0], ["\u2661", "Well nourished", "Logged a meal", d.diary.length > 0], ["\u25C7", "Hydrated", "Drink 8 glasses", d.water >= 8], ["\u2197", "On the move", "10,000 steps", d.steps >= 1e4], ["\u25C9", "Body aware", "Saved body stats", d.weights.length > 7], ["\u221E", "Seven day streak", "A full week", false]];
    return /* @__PURE__ */ jsxDEV("div", { className: "page", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "page-intro", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Look how far you've come." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 716
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Progress is built from showing up, again and again." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 750
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 711
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "segmented", children: [
          /* @__PURE__ */ jsxDEV("button", { className: period === "week" ? "active" : "", onClick: () => Period("week"), children: "Week" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 841
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: period === "month" ? "active" : "", onClick: () => Period("month"), children: "Month" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 931
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 814
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 50,
        columnNumber: 683
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "trend-cards", children: [["Current weight", f(d.weight, 1) + " kg", "-0.8 kg this month"], ["Steps this week", f(d.steps * 7), "Movement total"], ["Calories in / out", f(cals) + " / " + f(d.burned), "Today \xB7 kcal"], ["Protein target", d.proteinTarget + " g", "Daily goal"]].map((x) => /* @__PURE__ */ jsxDEV("div", { className: "panel trend-card", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "tiny-label", children: x[0] }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 1346
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "trend-value", children: x[1] }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 1386
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "trend-change", children: x[2] }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 1427
        }, this)
      ] }, x[0], true, {
        fileName: "<stdin>",
        lineNumber: 50,
        columnNumber: 1301
      }, this)) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 50,
        columnNumber: 1036
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Your trends" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 50,
              columnNumber: 1553
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Weekly activity and nutrition consistency" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 50,
              columnNumber: 1601
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 1548
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "chart-legend", children: [
            /* @__PURE__ */ jsxDEV("span", { children: [
              /* @__PURE__ */ jsxDEV("i", {}, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 50,
                columnNumber: 1715
              }, this),
              "Steps"
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 50,
              columnNumber: 1709
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: [
              /* @__PURE__ */ jsxDEV("i", { className: "second" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 50,
                columnNumber: 1737
              }, this),
              "Calories out"
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 50,
              columnNumber: 1731
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 1679
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 1520
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "trend-chart", children: trendSteps.map((v, i) => /* @__PURE__ */ jsxDEV("div", { className: "trend-bar-col", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "trend-bar", style: { height: Math.max(8, v / 95) + "%" } }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 1882
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "trend-bar alt", style: { height: Math.max(7, trendBurn[i] / 7) + "%", opacity: 0.65 } }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 1948
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: period === "week" ? ["M", "T", "W", "T", "F", "S", "S"][i] : i % 2 === 0 ? i + 1 : "" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 2040
          }, this)
        ] }, i, true, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 1843
        }, this)) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 1791
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "two-col", style: { marginTop: 20 }, children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Weight trend" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 50,
                  columnNumber: 2220
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: period === "week" ? "Last 7 days" : "Last month" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 50,
                  columnNumber: 2269
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 50,
                columnNumber: 2215
              }, this),
              /* @__PURE__ */ jsxDEV("strong", { children: [
                f(d.weight, 1),
                " kg"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 50,
                columnNumber: 2350
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 50,
              columnNumber: 2187
            }, this),
            weightChart()
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 2182
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Nutrition consistency" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 50,
              columnNumber: 2417
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Protein versus your daily target" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 50,
              columnNumber: 2475
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "goal-progress", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "goal-foot", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Protein target" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 50,
                  columnNumber: 2596
                }, this),
                /* @__PURE__ */ jsxDEV("strong", { children: [
                  f(prot),
                  " / ",
                  d.proteinTarget,
                  "g"
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 50,
                  columnNumber: 2623
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 50,
                columnNumber: 2569
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "progress-track", children: /* @__PURE__ */ jsxDEV("div", { className: "progress-fill", style: { width: Math.min(100, prot / d.proteinTarget * 100) + "%", background: "var(--cyan)" } }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 50,
                columnNumber: 2708
              }, this) }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 50,
                columnNumber: 2676
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 50,
              columnNumber: 2538
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "goal-progress", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "goal-foot", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Calories in" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 50,
                  columnNumber: 2894
                }, this),
                /* @__PURE__ */ jsxDEV("strong", { children: [
                  f(cals),
                  " / ",
                  d.calorieTarget,
                  " kcal"
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 50,
                  columnNumber: 2918
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 50,
                columnNumber: 2867
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "progress-track", children: /* @__PURE__ */ jsxDEV("div", { className: "progress-fill", style: { width: Math.min(100, cals / d.calorieTarget * 100) + "%", background: "var(--red)" } }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 50,
                columnNumber: 3007
              }, this) }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 50,
                columnNumber: 2975
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 50,
              columnNumber: 2836
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 2412
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 2134
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 50,
        columnNumber: 1483
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", style: { marginTop: 17 }, children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Personal records & milestones" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 3216
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Every first is worth celebrating" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 3282
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "badge-grid", children: badges.map((x) => /* @__PURE__ */ jsxDEV("div", { className: "badge " + (x[3] ? "earned" : ""), children: [
          /* @__PURE__ */ jsxDEV("div", { className: "badge-icon", children: x[0] }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 3444
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: x[1] }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 3484
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: x[2] }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 3507
          }, this)
        ] }, x[1], true, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 3388
        }, this)) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 3345
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 50,
        columnNumber: 3156
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 50,
      columnNumber: 661
    }, this);
  }
  function profilePage() {
    return /* @__PURE__ */ jsxDEV("div", { className: "page", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "page-intro", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Your plan, your pace." }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 51,
          columnNumber: 86
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Make FitPulse feel a little more like you." }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 51,
          columnNumber: 116
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 51,
        columnNumber: 81
      }, this) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 51,
        columnNumber: 53
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "profile-layout", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "profile-hero", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "avatar-large", children: d.name.split(" ").map((x) => x[0]).slice(0, 2).join("").toUpperCase() }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 281
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "profile-name", children: d.name }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 388
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "profile-sub", children: d.membership ? "FitPulse " + d.membership + " member" : "Your FitPulse profile" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 432
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 383
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 251
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "account-connected", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Signed in as" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 587
              }, this),
              /* @__PURE__ */ jsxDEV("strong", { children: authUser.email }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 612
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 552
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-grid", children: [
              [["Your name", "name", "text"], ["Age", "age", "number"], ["Height (cm)", "height", "number"], ["Weight (kg)", "weight", "number"]].map((x) => /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
                /* @__PURE__ */ jsxDEV("label", { children: x[0] }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 841
                }, this),
                /* @__PURE__ */ jsxDEV("input", { type: x[2], value: d[x[1]], onChange: (e) => set(x[1], x[2] === "number" ? +e.target.value : e.target.value) }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 862
                }, this)
              ] }, x[1], true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 807
              }, this)),
              /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Goal" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 1e3
                }, this),
                /* @__PURE__ */ jsxDEV("select", { value: d.goal, onChange: (e) => set("goal", e.target.value), children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "lose", children: "Lose weight" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 1083
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "maintain", children: "Maintain" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 1124
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "gain", children: "Gain weight" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 1166
                  }, this)
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 1019
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 977
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Activity level" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 1245
                }, this),
                /* @__PURE__ */ jsxDEV("select", { value: d.activity, onChange: (e) => set("activity", e.target.value), children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "sedentary", children: "Mostly sitting" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 1346
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "light", children: "Lightly active" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 1395
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "moderate", children: "Moderately active" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 1440
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "active", children: "Very active" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 1491
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "very", children: "Extra active" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 1534
                  }, this)
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 1274
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 1222
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Units" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 1614
                }, this),
                /* @__PURE__ */ jsxDEV("select", { value: d.unit, onChange: (e) => set("unit", e.target.value), children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "metric", children: "Metric \xB7 km, kg" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 1698
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "imperial", children: "Imperial \xB7 mi, lb" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 1745
                  }, this)
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 1634
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 1591
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Daily step goal" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 1834
                }, this),
                /* @__PURE__ */ jsxDEV("input", { type: "number", step: "500", value: d.stepGoal, onChange: (e) => set("stepGoal", +e.target.value) }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 1864
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 1811
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Calorie target" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 1991
                }, this),
                /* @__PURE__ */ jsxDEV("input", { type: "number", value: d.calorieTarget, onChange: (e) => set("calorieTarget", +e.target.value) }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 2020
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 1968
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Protein target (g)" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 2146
                }, this),
                /* @__PURE__ */ jsxDEV("input", { type: "number", value: d.proteinTarget, onChange: (e) => set("proteinTarget", +e.target.value) }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 2179
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 2123
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 651
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 51,
            columnNumber: 214
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", style: { marginTop: 15 }, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "App preferences" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 2391
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Saved on this device" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 2443
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 2386
              }, this),
              /* @__PURE__ */ jsxDEV("button", { className: "btn secondary small", onClick: theme, children: [
                "Use ",
                d.theme === "dark" ? "light" : "dark",
                " theme"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 2500
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 2358
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "switch-row", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Water goal (glasses / day)" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 2642
              }, this),
              /* @__PURE__ */ jsxDEV("input", { className: "inline-input", type: "number", style: { width: 75 }, value: d.waterGoal, onChange: (e) => set("waterGoal", +e.target.value) }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 2681
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 2614
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "switch-row", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Move goal (calories / day)" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 2848
              }, this),
              /* @__PURE__ */ jsxDEV("input", { className: "inline-input", type: "number", style: { width: 85 }, value: d.calorieGoal, onChange: (e) => set("calorieGoal", +e.target.value) }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 2887
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 2820
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "logout-row", children: [
              /* @__PURE__ */ jsxDEV("span", { children: [
                "Signed in as ",
                /* @__PURE__ */ jsxDEV("strong", { children: authUser.email }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 3077
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 3058
              }, this),
              /* @__PURE__ */ jsxDEV("button", { className: "btn ghost small", onClick: async () => {
                await fetch("/api/account/logout", { method: "POST" });
                AuthUser(null);
                Plan(null);
              }, children: "Log out" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 3117
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 3030
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 51,
            columnNumber: 2298
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 51,
          columnNumber: 209
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "FitPulse membership" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 3364
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Choose how you want to show up" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 3420
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 3359
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "stat-symbol", children: /* @__PURE__ */ jsxDEV(I, { n: "crown" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 3517
              }, this) }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 3487
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 3331
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "plans-grid", style: { gridTemplateColumns: "1fr" }, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "plan-card", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "plan-name", children: "Monthly" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 3635
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "plan-price", children: [
                  "\u20B9199 ",
                  /* @__PURE__ */ jsxDEV("small", { children: "/ month" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 3708
                  }, this)
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 3675
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "plan-copy", children: "A little more support, billed monthly." }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 3736
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "check-list", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "check-line", children: [
                    /* @__PURE__ */ jsxDEV("i", { children: "\u2713" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 51,
                      columnNumber: 3863
                    }, this),
                    " Deeper activity insights"
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 3835
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "check-line", children: [
                    /* @__PURE__ */ jsxDEV("i", { children: "\u2713" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 51,
                      columnNumber: 3930
                    }, this),
                    " Progress trends and milestones"
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 3902
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "check-line", children: [
                    /* @__PURE__ */ jsxDEV("i", { children: "\u2713" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 51,
                      columnNumber: 4003
                    }, this),
                    " Flexible monthly membership"
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 3975
                  }, this)
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 3807
                }, this),
                /* @__PURE__ */ jsxDEV("button", { className: "btn secondary full", onClick: () => buy({ key: "monthly" }), disabled: orderBusy, children: orderBusy ? "Preparing..." : "Buy membership" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 4051
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 3608
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "plan-card featured", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "status-pill", style: { color: "var(--green)" }, children: "BEST VALUE" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 4240
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "plan-name", style: { marginTop: 9 }, children: "Annual" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 4318
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "plan-price", children: [
                  "\u20B91,499 ",
                  /* @__PURE__ */ jsxDEV("small", { children: "/ year" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 4414
                  }, this)
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 4379
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "plan-copy", children: "A whole year of making progress, for less." }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 4441
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "check-list", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "check-line", children: [
                    /* @__PURE__ */ jsxDEV("i", { children: "\u2713" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 51,
                      columnNumber: 4572
                    }, this),
                    " Everything in monthly"
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 4544
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "check-line", children: [
                    /* @__PURE__ */ jsxDEV("i", { children: "\u2713" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 51,
                      columnNumber: 4636
                    }, this),
                    " Save over 35% annually"
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 4608
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "check-line", children: [
                    /* @__PURE__ */ jsxDEV("i", { children: "\u2713" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 51,
                      columnNumber: 4701
                    }, this),
                    " One simple yearly payment"
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 51,
                    columnNumber: 4673
                  }, this)
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 4516
                }, this),
                /* @__PURE__ */ jsxDEV("button", { className: "btn full", onClick: () => buy({ key: "annual" }), disabled: orderBusy, children: orderBusy ? "Preparing..." : "Buy membership" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 51,
                  columnNumber: 4747
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 4204
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 3544
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "settings-note", children: "Membership is paid directly via UPI. Payment QR appears only during membership checkout." }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 4895
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 51,
            columnNumber: 3294
          }, this),
          d.membership && /* @__PURE__ */ jsxDEV("div", { className: "membership-success", children: [
            "You're on the FitPulse ",
            d.membership,
            " plan. Thanks for being here."
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 51,
            columnNumber: 5041
          }, this),
          d.pendingMembership && /* @__PURE__ */ jsxDEV("div", { className: "membership-success", style: { color: "var(--muted)" }, children: [
            "Your ",
            d.pendingMembership,
            " order is awaiting manual payment confirmation."
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 51,
            columnNumber: 5172
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", style: { marginTop: 15 }, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "tiny-label", children: "Your daily rhythm" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 5379
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "result-metric", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Step goal" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 5461
              }, this),
              /* @__PURE__ */ jsxDEV("strong", { children: [
                f(d.stepGoal),
                " steps"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 5483
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 5430
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "result-metric", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Calories" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 5558
              }, this),
              /* @__PURE__ */ jsxDEV("strong", { children: [
                f(d.calorieTarget),
                " kcal"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 5579
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 5527
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "result-metric", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Protein" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 5658
              }, this),
              /* @__PURE__ */ jsxDEV("strong", { children: [
                f(d.proteinTarget),
                " g"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 51,
                columnNumber: 5678
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 51,
              columnNumber: 5627
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 51,
            columnNumber: 5319
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 51,
          columnNumber: 3289
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 51,
        columnNumber: 177
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 51,
      columnNumber: 31
    }, this);
  }
  function checkoutPage() {
    if (!plan) return null;
    let pay = "upi://pay?pa=7303232301@axl&pn=FitPulse&mc=0000&mode=02&purpose=00&am=" + plan.price.toFixed(2) + "&cu=INR", qr = "https://api.qrserver.com/v1/create-qr-code/?size=280x280&margin=8&data=" + encodeURIComponent(pay);
    return /* @__PURE__ */ jsxDEV("div", { className: "page checkout-wrap", children: [
      /* @__PURE__ */ jsxDEV("button", { className: "back-link", onClick: () => Plan(null), children: "\u2190 Back to membership plans" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 52,
        columnNumber: 303
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "checkout-title", children: "One last step to your next level." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 52,
        columnNumber: 393
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "checkout-sub", children: "Review your membership and complete payment with any UPI app." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 52,
        columnNumber: 462
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "checkout-grid", children: [
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "panel-head", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Order summary" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 52,
                columnNumber: 656
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "Your FitPulse membership" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 52,
                columnNumber: 706
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 651
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "status-pill", children: "1 ITEM" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 767
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 623
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "order-line", style: { marginTop: 14 }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: plan.name }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 867
            }, this),
            /* @__PURE__ */ jsxDEV("strong", { children: [
              "\u20B9",
              f(plan.price, 2)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 891
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 816
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "order-line", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Quantity" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 960
            }, this),
            /* @__PURE__ */ jsxDEV("strong", { children: "1" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 981
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 932
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "order-line", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Payment method" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 1033
            }, this),
            /* @__PURE__ */ jsxDEV("strong", { children: "UPI" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 1060
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 1005
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "order-total", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Total due" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 1115
            }, this),
            /* @__PURE__ */ jsxDEV("strong", { children: [
              "\u20B9",
              f(plan.price, 2)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 1137
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 1086
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "field", style: { marginTop: 22 }, children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Name for your order (optional)" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 1224
            }, this),
            /* @__PURE__ */ jsxDEV("input", { value: orderName, onChange: (e) => ON(e.target.value), placeholder: "Your name" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 1269
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 1178
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "membership-success", style: { color: "var(--muted)" }, children: "QR payments are available only for FitPulse membership subscriptions." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 1358
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 52,
          columnNumber: 586
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "panel panel-pad checkout-right", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "section-heading", children: "Pay with UPI" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 1567
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: [
              "Scan this code to pay \u20B9",
              f(plan.price, 2)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 1616
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 1562
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "qr-box", children: /* @__PURE__ */ jsxDEV("img", { src: qr, alt: "UPI payment QR code for Rs " + plan.price }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 1717
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 1693
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "upi-label", children: [
            "Pay to ",
            /* @__PURE__ */ jsxDEV("strong", { children: "FitPulse" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 1819
            }, this),
            " \xB7 ",
            /* @__PURE__ */ jsxDEV("strong", { children: "7303232301@axl" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 1847
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 1785
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "pay-note", children: "Scan and pay using any UPI app. After paying, tap below to confirm your order. Payment verification is manual." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 1884
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn full checkout-confirm", onClick: confirm, children: [
            "Confirm Order on WhatsApp ",
            /* @__PURE__ */ jsxDEV(I, { n: "chart", size: 14 }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 52,
              columnNumber: 2112
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 2022
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 52,
          columnNumber: 1510
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 52,
        columnNumber: 555
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 52,
      columnNumber: 267
    }, this);
  }
  if (authLoading) return /* @__PURE__ */ jsxDEV("div", { className: "auth-loading", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "brand-mark", children: /* @__PURE__ */ jsxDEV(I, { n: "bolt" }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 53,
      columnNumber: 82
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 53,
      columnNumber: 53
    }, this),
    /* @__PURE__ */ jsxDEV("strong", { children: "FitPulse" }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 53,
      columnNumber: 102
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 53,
    columnNumber: 23
  }, this);
  if (!authUser) return /* @__PURE__ */ jsxDEV(AuthScreen, { onAuth: (account) => {
    AuthUser(account);
    let saved = localStorage.getItem("fitpulse-data:" + account.email);
    S(saved ? load(account.email) : { ...load(account.email), name: account.name });
    ON(account.name);
  } }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 53,
    columnNumber: 154
  }, this);
  const title = plan ? "Membership checkout" : names[page];
  return /* @__PURE__ */ jsxDEV("div", { className: "app-shell", children: [
    side,
    /* @__PURE__ */ jsxDEV("main", { className: "main-wrap", children: [
      /* @__PURE__ */ jsxDEV("header", { className: "topbar", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "date-kicker", children: today }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 54,
            columnNumber: 101
          }, this),
          /* @__PURE__ */ jsxDEV("h1", { className: "header-title", children: title }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 54,
            columnNumber: 143
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 54,
          columnNumber: 96
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "top-actions", children: [
          /* @__PURE__ */ jsxDEV("button", { className: "btn secondary small share-btn", onClick: shareProject, children: [
            /* @__PURE__ */ jsxDEV(I, { n: "share", size: 15 }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 54,
              columnNumber: 292
            }, this),
            " Share"
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 54,
            columnNumber: 219
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "icon-btn", "aria-label": "Toggle theme", onClick: theme, children: /* @__PURE__ */ jsxDEV(I, { n: d.theme === "dark" ? "sun" : "moon" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 54,
            columnNumber: 402
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 54,
            columnNumber: 331
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "user-pill", onClick: () => go("profile"), children: d.name.split(" ").map((x) => x[0]).slice(0, 2).join("").toUpperCase() }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 54,
            columnNumber: 449
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 54,
          columnNumber: 190
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 54,
        columnNumber: 69
      }, this),
      plan ? checkoutPage() : page === "dashboard" ? dashboard() : page === "body" ? bodyPage() : page === "activity" ? activityPage() : page === "nutrition" ? nutritionPage() : page === "progress" ? progressPage() : profilePage()
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 54,
      columnNumber: 41
    }, this),
    /* @__PURE__ */ jsxDEV("nav", { className: "mobile-nav", children: nav.filter((x) => x[0] !== "profile").map((x) => navBtn(x, true)) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 54,
      columnNumber: 796
    }, this),
    toast && /* @__PURE__ */ jsxDEV("div", { className: "toast", role: "status", children: toast }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 54,
      columnNumber: 894
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 54,
    columnNumber: 8
  }, this);
}
createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 55,
  columnNumber: 52
}));
