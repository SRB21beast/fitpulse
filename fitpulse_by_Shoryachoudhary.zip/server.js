const encoder = new TextEncoder();
const SESSION_SECONDS = 60 * 60 * 24 * 30;
const ITERATIONS = 100000;

export const schema = [
  "CREATE TABLE IF NOT EXISTS fitpulse_accounts (user_id TEXT PRIMARY KEY, username TEXT NOT NULL, email TEXT NOT NULL UNIQUE, name TEXT NOT NULL, salt TEXT NOT NULL, password_hash TEXT NOT NULL, failed_attempts INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)",
  "CREATE TABLE IF NOT EXISTS fitpulse_sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires_at INTEGER NOT NULL, created_at TEXT NOT NULL)",
  "CREATE INDEX IF NOT EXISTS fitpulse_sessions_user ON fitpulse_sessions(user_id)",
  "CREATE TABLE IF NOT EXISTS fitpulse_orders (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, email TEXT NOT NULL, plan TEXT NOT NULL, amount INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending_payment', created_at TEXT NOT NULL)",
  "CREATE INDEX IF NOT EXISTS fitpulse_orders_user ON fitpulse_orders(user_id)"
].join(";\n") + ";";

function encode(bytes) {
  return btoa(String.fromCharCode(...new Uint8Array(bytes)))
    .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function decode(value) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  return Uint8Array.from(atob(normalized), (c) => c.charCodeAt(0));
}

async function digest(value) {
  return encode(await crypto.subtle.digest("SHA-256", encoder.encode(value)));
}

async function passwordHash(password, salt) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: decode(salt), iterations: ITERATIONS, hash: "SHA-256" }, key, 256);
  return encode(bits);
}

function equal(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function json(data, status = 200, headers = {}) {
  return Response.json(data, { status, headers });
}

function sessionCookie(token, maxAge = SESSION_SECONDS) {
  return "fp_session=" + token + "; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=" + maxAge;
}

function readCookie(request) {
  const match = (request.headers.get("cookie") || "").match(/(?:^|;\s*)fp_session=([^;]+)/);
  return match ? match[1] : null;
}

function platformUserId(request) {
  return request.headers.get("x-websim-user-id");
}

async function createSession(env, userId) {
  const raw = encode(crypto.getRandomValues(new Uint8Array(32)));
  const now = Math.floor(Date.now() / 1000);
  await env.DB.prepare("INSERT INTO fitpulse_sessions (token_hash, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)")
    .bind(await digest(raw), userId, now + SESSION_SECONDS, new Date().toISOString()).run();
  return raw;
}

async function accountForRequest(request, env) {
  const userId = platformUserId(request);
  const raw = readCookie(request);
  if (!userId || !raw) return null;
  const tokenHash = await digest(raw);
  const now = Math.floor(Date.now() / 1000);
  return await env.DB.prepare(
    "SELECT a.user_id, a.email, a.name, a.username FROM fitpulse_sessions s " +
    "JOIN fitpulse_accounts a ON a.user_id = s.user_id " +
    "WHERE s.token_hash = ? AND s.user_id = ? AND s.expires_at > ?"
  ).bind(tokenHash, userId, now).first();
}

function normalizeEmail(value) {
  return typeof value === "string" ? value.trim().toLowerCase() : "";
}

function validEmail(value) {
  return value.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

async function bodyJson(request) {
  try { return await request.json(); } catch { return null; }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const userId = platformUserId(request);
    const username = request.headers.get("x-websim-username") || "websim-user";

    if (url.pathname === "/api/account/register" && request.method === "POST") {
      if (!userId) return json({ error: "Sign in to Websim before creating a FitPulse account.", code: "websim_signin_required" }, 401);
      const body = await bodyJson(request);
      const email = normalizeEmail(body?.email);
      const password = typeof body?.password === "string" ? body.password : "";
      const name = typeof body?.name === "string" ? body.name.trim().slice(0, 80) : "";
      if (!validEmail(email)) return json({ error: "Enter a valid email address." }, 400);
      if (password.length < 8 || password.length > 128) return json({ error: "Use a password between 8 and 128 characters." }, 400);
      if (!name) return json({ error: "Enter your name." }, 400);
      const existingUser = await env.DB.prepare("SELECT user_id FROM fitpulse_accounts WHERE user_id = ?").bind(userId).first();
      if (existingUser) return json({ error: "A FitPulse account is already linked to this Websim account. Log in instead." }, 409);
      const salt = encode(crypto.getRandomValues(new Uint8Array(16)));
      const hashed = await passwordHash(password, salt);
      try {
        await env.DB.prepare("INSERT INTO fitpulse_accounts (user_id, username, email, name, salt, password_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)")
          .bind(userId, username, email, name, salt, hashed, new Date().toISOString()).run();
      } catch {
        return json({ error: "That email is already registered." }, 409);
      }
      const token = await createSession(env, userId);
      return json({ account: { email, name } }, 201, { "Set-Cookie": sessionCookie(token) });
    }

    if (url.pathname === "/api/account/login" && request.method === "POST") {
      if (!userId) return json({ error: "Sign in to Websim before logging into FitPulse." , code: "websim_signin_required" }, 401);
      const body = await bodyJson(request);
      const email = normalizeEmail(body?.email);
      const password = typeof body?.password === "string" ? body.password : "";
      if (!validEmail(email) || !password || password.length > 128) return json({ error: "Email or password is incorrect." }, 401);
      const row = await env.DB.prepare("SELECT user_id, email, name, salt, password_hash, failed_attempts, locked_until FROM fitpulse_accounts WHERE email = ?").bind(email).first();
      const salt = row?.salt || encode(encoder.encode("fitpulse-dummy-salt"));
      const candidate = await passwordHash(password, salt);
      const now = Math.floor(Date.now() / 1000);
      const locked = row && row.user_id === userId && row.locked_until > now;
      const matches = row && row.user_id === userId && equal(candidate, row.password_hash);
      if (!matches || locked) {
        if (row && row.user_id === userId && !locked) {
          await env.DB.prepare("UPDATE fitpulse_accounts SET failed_attempts = failed_attempts + 1, locked_until = CASE WHEN failed_attempts + 1 >= 10 THEN ? ELSE locked_until END WHERE user_id = ?")
            .bind(now + 900, userId).run();
        }
        return json({ error: locked ? "Too many attempts. Try again in 15 minutes." : "Email or password is incorrect." }, locked ? 429 : 401);
      }
      await env.DB.prepare("UPDATE fitpulse_accounts SET failed_attempts = 0, locked_until = 0 WHERE user_id = ?").bind(userId).run();
      const token = await createSession(env, userId);
      return json({ account: { email: row.email, name: row.name } }, 200, { "Set-Cookie": sessionCookie(token) });
    }

    if (url.pathname === "/api/account/session" && request.method === "GET") {
      const account = await accountForRequest(request, env);
      if (!account) return json({ account: null });
      return json({ account: { email: account.email, name: account.name } });
    }

    if (url.pathname === "/api/account/logout" && request.method === "POST") {
      const raw = readCookie(request);
      if (raw) await env.DB.prepare("DELETE FROM fitpulse_sessions WHERE token_hash = ?").bind(await digest(raw)).run();
      return json({ ok: true }, 200, { "Set-Cookie": sessionCookie("", 0) });
    }

    if (url.pathname === "/api/orders" && request.method === "POST") {
      const account = await accountForRequest(request, env);
      if (!account) return json({ error: "Log in to place a membership order." }, 401);
      const body = await bodyJson(request);
      const plans = { monthly: { name: "Monthly Membership", amount: 199 }, annual: { name: "Annual Membership", amount: 1499 } };
      const selected = plans[body?.plan];
      if (!selected) return json({ error: "Choose a valid membership plan." }, 400);
      const order = { id: crypto.randomUUID(), ...selected, createdAt: new Date().toISOString() };
      await env.DB.prepare("INSERT INTO fitpulse_orders (id, user_id, email, plan, amount, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)")
        .bind(order.id, account.user_id, account.email, order.name, order.amount, "pending_payment", order.createdAt).run();
      return json({ order }, 201);
    }

    return new Response("Not found", { status: 404 });
  },
};
